import Product from './Product';
import './Product.css';

export default Product;
